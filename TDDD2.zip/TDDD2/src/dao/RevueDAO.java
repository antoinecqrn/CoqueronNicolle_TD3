package dao;
import metier.RevuePOJO;



public abstract interface RevueDAO extends DAO<RevuePOJO> {



	
}

		