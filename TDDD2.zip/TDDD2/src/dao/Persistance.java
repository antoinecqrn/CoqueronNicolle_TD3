package dao;

public enum Persistance {
	
	MYSQL, NO_SQL, LISTE_MEMOIRE;
	

}
