package dao;
import metier.AbonnementPOJO;


public abstract interface AbonnementDAO extends DAO<AbonnementPOJO>{
	

	}


