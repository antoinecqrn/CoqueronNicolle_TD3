package dao;

import metier.PeriodicitePOJO;


public abstract interface  PeriodiciteDAO extends DAO<PeriodicitePOJO> {


	
	
	}
		
		
		
		
		
 

		

	
	
	


